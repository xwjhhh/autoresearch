# 08-运行环境

AutoResearch 0.4.1 的 08-运行环境 前后端关键源码提取包。

包含对应页面、Electron IPC、preload 桥接、服务模块和直接依赖。排除 data/、聊天记录、实验环境、凭据和 node_modules。
